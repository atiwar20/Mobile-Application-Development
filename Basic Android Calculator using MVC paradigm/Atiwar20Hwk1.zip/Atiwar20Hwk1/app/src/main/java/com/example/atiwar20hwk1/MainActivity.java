package com.example.atiwar20hwk1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText inputText1, inputText2;
    private Button buttonAdd, buttonSub, buttonMul, buttonDiv;
    private TextView viewResult;
    private double number1, number2, result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputText1 = (EditText) findViewById(R.id.inputText1);
        inputText2 = (EditText) findViewById(R.id.inputText2);
        viewResult = (TextView) findViewById(R.id.viewResult);
        buttonAdd = (Button) findViewById(R.id.buttonAdd);
        buttonMul = (Button) findViewById(R.id.buttonMul);
        buttonSub = (Button) findViewById(R.id.buttonSub);
        buttonDiv = (Button) findViewById(R.id.buttonDiv);


        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.w( "MainActivity", "v = " + v );
                if (!inputText1.getText().toString().equals("") || !inputText2.getText().toString().equals("")){
                    number1 = Double.parseDouble(inputText1.getText().toString());
                    number2 = Double.parseDouble(inputText2.getText().toString());
                    result = number1 + number2;
                    viewResult.setText(number1 + " + " + number2 + " = " + result);
                }
            }
        });

        buttonMul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.w( "MainActivity", "v = " + v );
                if (!inputText1.getText().toString().equals("") || !inputText2.getText().toString().equals("")){
                    number1 = Double.parseDouble(inputText1.getText().toString());
                    number2 = Double.parseDouble(inputText2.getText().toString());
                    result = number1 * number2;
                    viewResult.setText(number1 + " * " + number2 + " = " + result);
                }
            }
        });

        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.w( "MainActivity", "v = " + v );
                if (!inputText1.getText().toString().equals("") || !inputText2.getText().toString().equals("")){
                    number1 = Double.parseDouble(inputText1.getText().toString());
                    number2 = Double.parseDouble(inputText2.getText().toString());
                    result = number1 - number2;
                    viewResult.setText(number1 + " - " + number2 + " = " + result);
                }
            }
        });

        buttonDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.w( "MainActivity", "v = " + v );
                if (!inputText1.getText().toString().equals("") || !inputText2.getText().toString().equals("")){
                    number1 = Double.parseDouble(inputText1.getText().toString());
                    number2 = Double.parseDouble(inputText2.getText().toString());
                    result = number1 / number2;
                    viewResult.setText(number1 + " / " + number2 + " = " + result);
                }
            }
        });


    }
}
